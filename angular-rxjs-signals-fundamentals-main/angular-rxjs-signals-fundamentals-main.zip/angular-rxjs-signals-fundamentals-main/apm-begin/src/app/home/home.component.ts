import { Component } from '@angular/core';

@Component({
    templateUrl: './home.component.html',
    standalone: true
})
export class HomeComponent {
  public pageTitle = 'Welcome';
}
